package com.example.student.myapplication;
import android.view.View;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

public class MainActivity extends AppCompatActivity {
    private TextSwitcher longStuff;
    private Button btn;
    private Button bttn;
    private Paint paint = new Paint();
    String textToShow[] = {"Never going to give you up","Never going to let you down",
            "Never gonna run around and desert you", "Never gonna make you cry",
            "Never gonna say goodbye",
            "Never gonna tell a lie and hurt you\n",
            "We've known each other for so long\n" +
            "Your heart's been aching but\n" +
            "You're too shy to say it\n",
            "Inside we both know what's been going on",
            "We know the game and we're gonna play it\n" +
                    "And if you ask me how I'm feeling\n" +
                    "Don't tell me you're too blind to see\n",
            "Never gonna give you up\n" +
                    "Never gonna let you down\n" +
                    "Never gonna run around and desert you\n"
        };
    int messageCount = textToShow.length;
    // to keep current Index of text
    int currentIndex = -1;
    int x,y;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = (Button) findViewById(R.id.button);
        bttn = (Button) findViewById(R.id.button);
        longStuff = (TextSwitcher) findViewById(R.id.longStuff);
        longStuff.setFactory(new ViewSwitcher.ViewFactory() {

            public View makeView() {
                // TODO Auto-generated method stub
                // create new textView and set the properties like clolr, size etc
                TextView myText = new TextView(MainActivity.this);
                myText.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
                myText.setTextSize(36);
                myText.setTextColor(Color.BLUE);
                return myText;
            }
        });

        Animation in = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);
        Animation out = AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right);
        longStuff.setInAnimation(in);
        longStuff.setOutAnimation(out);
        class myView extends View {
            private Paint paint;

            public myView(Context context) {
                super(context);
                init();
            }

            private void init() {
                paint = new Paint();
                paint.setStyle(Paint.Style.FILL_AND_STROKE);
                invalidate(); //causes a canvas draw
            }

            protected void onDraw(Canvas canvas) {
                paint.setColor(Color.rgb(255, 255, 0));
                paint.setStyle(Paint.Style.FILL);
                canvas.drawRect(0, 0, x, y, paint);
                paint.setTextSize(100);
                canvas.drawText("3350 Lab-11", 0, 70, paint);
            }
        }

            public void draw(View view) {
                myView v;
                v = new myView(this);
                setContentView(v);
            }


        btn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View view) {

            currentIndex++;
            // If index reaches maximum reset it
            if (currentIndex == messageCount)
                currentIndex = 0;
            longStuff.setText(textToShow[currentIndex]);
            Toast.makeText(getApplication().getBaseContext(), "ToaST",
                    Toast.LENGTH_SHORT).show();


            }

        });


    }
}